const User = require("../models/user-model");
const generateToken = require("../utils/generate-token");

const signup = async (req, res) => {
  try {
    const { name, email, password, role, phone, bio } = req.body;

    const existingUser = await User.findOne({ email });
    if (existingUser) {
      return res.status(400).json({
        status: "error",
        message: "Email already registered",
      });
    }

    const newUser = await User.create({
      name,
      email,
      password,
      role,
      phone,
      bio,
    });

    const token = generateToken(newUser._id);

    res.status(201).json({
      status: "success",
      message: "User registered successfully",
      token,
      data: {
        user: {
          id: newUser._id,
          name: newUser.name,
          email: newUser.email,
          role: newUser.role,
        },
      },
    });
  } catch (error) {
    res.status(400).json({
      status: "error",
      message: `Error in signup: ${error.message}`,
    });
  }
};

const login = async (req, res) => {
  try {
    const { email, password } = req.body;

    if (!email || !password) {
      return res.status(400).json({
        status: "error",
        message: "Email and password are required",
      });
    }

    const user = await User.findOne({ email }).select("+password");

    if (!user || !(await user.comparePassword(password))) {
      return res.status(401).json({
        status: "error",
        message: "Incorrect email or password",
      });
    }

    const token = generateToken(user._id);

    res.status(200).json({
      status: "success",
      message: "Logged in successfully",
      token,
      data: {
        user: {
          id: user._id,
          name: user.name,
          email: user.email,
          role: user.role,
        },
      },
    });
  } catch (error) {
    res.status(400).json({
      status: "error",
      message: `Error in login: ${error.message}`,
    });
  }
};

// Protected route used to test that the JWT works (returns the logged-in user)
const getMe = async (req, res) => {
  try {
    const user = await User.findById(req.user.id);

    res.status(200).json({
      status: "success",
      data: {
        user,
      },
    });
  } catch (error) {
    res.status(400).json({
      status: "error",
      message: `Error in fetching profile: ${error.message}`,
    });
  }
};

module.exports = {
  signup,
  login,
  getMe,
};
