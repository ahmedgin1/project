# Authentication Module — Course Platform API

## What this module does

This module adds user authentication to the course platform backend using **Mongoose**, **bcryptjs**, and **jsonwebtoken (JWT)**. It lets users register and log in, hashes passwords before storing them, issues JWTs on signup/login, and provides a `protect` middleware to guard private routes plus a `restrictTo` middleware for role-based access.

## User roles

The platform has two roles:

- **instructor** — creates and manages courses
- **student** (default) — browses and enrolls in courses

`role` is stored on the `User` model and can be used with `restrictTo("instructor")` to lock down instructor-only routes (e.g. creating a course).

## User model fields

| Field    | Type   | Notes                                  |
| -------- | ------ | --------------------------------------- |
| name     | String | required                                |
| email    | String | required, unique                        |
| password | String | required, hashed with bcrypt, never returned by default |
| role     | String | `instructor` or `student`, default `student` |
| phone    | String | optional                                |
| photo    | String | optional (ready for multer in a later session) |
| bio      | String | optional                                |

## Routes

Base URL: `/api/v1/auth`

| Method | Route     | Access  | Description                          |
| ------ | --------- | ------- | ------------------------------------- |
| POST   | `/signup` | Public  | Register a new user, returns a JWT   |
| POST   | `/login`  | Public  | Authenticate a user, returns a JWT   |
| GET    | `/me`     | Private | Returns the logged-in user (requires token) |

### POST /api/v1/auth/signup

Request body:

```json
{
  "name": "Sara Ahmed",
  "email": "sara@example.com",
  "password": "123456",
  "role": "student",
  "phone": "01000000000"
}
```

Response (201):

```json
{
  "status": "success",
  "message": "User registered successfully",
  "token": "eyJhbGciOi...",
  "data": {
    "user": {
      "id": "665f1c2e...",
      "name": "Sara Ahmed",
      "email": "sara@example.com",
      "role": "student"
    }
  }
}
```

### POST /api/v1/auth/login

Request body:

```json
{
  "email": "sara@example.com",
  "password": "123456"
}
```

Response (200) — same shape as signup, with a fresh token. A wrong email/password returns `401` with `"Incorrect email or password"`.

### GET /api/v1/auth/me (protected)

Requires the token from signup/login in the `Authorization` header:

```
Authorization: Bearer eyJhbGciOi...
```

Response (200):

```json
{
  "status": "success",
  "data": {
    "user": {
      "id": "665f1c2e...",
      "name": "Sara Ahmed",
      "email": "sara@example.com",
      "role": "student",
      "createdAt": "...",
      "updatedAt": "..."
    }
  }
}
```

Without a valid token, this route returns `401 Not authorized, no token provided` (or `invalid or expired token`).

## Protecting other routes

Any route can be locked down the same way, e.g. only instructors can create a course:

```js
const { protect, restrictTo } = require("../middlewares/auth-middleware");

router
  .route("/")
  .get(courseControllers.getAllCourses)
  .post(protect, restrictTo("instructor"), upload.single("imageUrl"), courseControllers.createCourse);
```

## How to run locally

1. Install dependencies:

   ```bash
   npm install
   ```

2. Create a `.env` file in the project root (see `.env.example`):

   ```
   PORT=3000
   MONGODB_URI=mongodb://127.0.0.1:27017
   DB_NAME=course_platform
   JWT_SECRET=replace_with_a_long_random_secret
   JWT_EXPIRES_IN=7d
   ```

3. Start the server:

   ```bash
   npm start
   ```

4. Test with Postman:
   - `POST http://localhost:3000/api/v1/auth/signup`
   - `POST http://localhost:3000/api/v1/auth/login`
   - `GET http://localhost:3000/api/v1/auth/me` with the returned token as a Bearer token
   - Also try logging in with a wrong password to confirm you get a `401`

## Project structure

```
controllers/
  auth-controllers.js      # signup, login, getMe
  course-controllers.js
middlewares/
  auth-middleware.js       # protect, restrictTo
  multer-middleware.js
models/
  user-model.js            # User schema + password hashing
  course-model.js
routes/
  auth-routes.js
  course-routes.js
utils/
  generate-token.js        # JWT signing helper
  delete-uploaded-file.js
config/
  db-connect.js
index.js
```

## Next steps (planned for a future session)

- User profile photo upload with `multer` (the `photo` field and upload folder structure are already in place)
- Full role-based access control across all course routes
