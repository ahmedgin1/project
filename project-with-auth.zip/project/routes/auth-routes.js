const express = require("express");
const authControllers = require("../controllers/auth-controllers");
const { protect } = require("../middlewares/auth-middleware");

const router = express.Router();

router.post("/signup", authControllers.signup);
router.post("/login", authControllers.login);

// Protected route, used to test the token from Postman
router.get("/me", protect, authControllers.getMe);

module.exports = router;
